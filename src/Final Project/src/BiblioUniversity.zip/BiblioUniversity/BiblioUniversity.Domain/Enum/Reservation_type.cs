﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BiblioUniversity.Domain.Enum
{
    public enum Reservation_type
    {
        Digital_reservation,
        Personal_reservation
    }
}
